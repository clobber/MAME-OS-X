/******************************************************************************
 Copyright (c) 2005-2006 Jordy Rose
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 
 Except as contained in this notice, the name(s) of the above copyright holders
 shall not be used in advertising or otherwise to promote the sale, use or other
 dealings in this Software without prior authorization.
*******************************************************************************/

#import <Foundation/NSGeometry.h>
@class NSMutableArray, NSWindow, NSEvent;

#pragma mark PRIVATE class from InterfaceBuilder.app

#define CLASS_IBConnectionManager InterfaceBuilder_App_CLASS_IBConnectionManager
/*!
 * Represents the <code>IBConnectionManager</code> class. In any class that uses
 * this variable, add this line of code to its <code>+initialize</code> method:
 * <code>CLASS_IBConnectionManager = NSClassFromString(@"IBConnectionManager");</code>
 *
 * @see IBConnectionManager
 */
extern Class CLASS_IBConnectionManager;

/*!
 * Manages connections between objects in Interface Builder (specifically making
 * and displaying them). This is a PRIVATE class from InterfaceBuilder.app, so you
 * will only be able to access the class through the global variable {@link CLASS_IBConnectionManager}.
 * The most useful method is {@link #trackConnectionFromObject:inWindow:event:}, which
 * allows custom editors to make connections using the usual control-click method.
 * WARNING: this class is a PRIVATE part of InterfaceBuilder.app, so any documentation
 * and usage is not guaranteed to be correct or safe.
 */
@interface IBConnectionManager : NSObject
{
    id _source;
    NSWindow *_sourceWindow;
    id _destination;
    NSWindow *_destinationWindow;
    BOOL _isConnecting;
    NSMutableArray *ignoredTrackerWindows;
    BOOL _resuffleWindows;
}
/*!
 * Returns the connection manager shared across Interface Builder.
 * @functiongroup Getting the shared instance
 */
+ (id)sharedConnectionManager;
- (id)source;
- (id)sourceWindow;
- (id)destination;
- (id)destinationWindow;

/*!
 * @functiongroup Making connections
 */
/*!
 * Starts tracking a connection from <code>object</code> by drawing a connection line.
 * <code>window</code> is the window that the object is in, and <code>mouseEvent</code>
 * is the event that started the connection, usually a control-click/drag.
 * (MINIMALLY TESTED ONLY)
 */
- (void)trackConnectionFromObject:(id)object inWindow:(NSWindow *)window event:(NSEvent *)mouseEvent;
/*!
 * Attaches the current connection to the object at <code>point</code>, with its connection
 * frame in <code>rect</code>. Returns the destination.
 * (UNTESTED)
 */
- (id)connectDestinationAtPoint:(NSPoint)point rect:(NSRectPointer)rect;
/*!
 * Returns <code>YES</code> if a connection is in progress, <code>NO</code> if not.
 * This method is also publicly implemented on NSApplication in InterfaceBuilder.framework.
 * (UNTESTED)
 */
- (BOOL)isConnecting;
/*!
 * If connection stopping is enabled, stops the connection currently being made.
 * This method is also publicly implemented on NSApplication in InterfaceBuilder.framework.
 * (UNTESTED)
 * @see #disableStopConnecting
 * @see #enableStopConnecting
 */
- (void)stopConnecting;
/*!
 * Disallows connection stopping, making the current connection effectively mandatory.
 * (UNTESTED)
 * @see #stopConnecting
 * @see #enableStopConnecting
 */
- (void)disableStopConnecting;
/*!
 * Allows connection stopping, making the current connection able to be broken.
 * (UNTESTED)
 * @see #stopConnecting
 * @see #disableStopConnecting
 */
- (void)enableStopConnecting;

/*!
 * @functiongroup Displaying connections
 */
/*!
 * Shows the connection between <code>source</code> and <code>dest</code> by bringing
 * their editors to the front and drawing the connection line. This method is also
 * publicly implemented on NSApplication as <code>displayConnectionBetweenSource:and:</code>
 * in InterfaceBuilder.framework.
 * (UNTESTED)
 */
- (void)displayConnectionBetweenSource:(id)source andDestination:(id)dest;
/*!
 * Displays the connection frame for <code>target</code>. If <code>target</code> cannot
 * be found, displays <code>rect</code>, otherwise puts the actual frame in <code>rect</code>.
 * (UNTESTED AND UNKNOWN)
 * @see #hideConnectFrame
 */
- (void)showConnectFrame:(NSRectPointer)rect target:(id)target;
/*!
 * Hides the connection frame. If it is not currently being displayed, does nothing.
 * (UNTESTED)
 * @see #showConnectFrame:target:
 */
- (void)hideConnectFrame;
/*!
 * Displays the connection arrow (probably the little square on the source) for
 * <code>object</code>.
 * (UNTESTED AND UNKNOWN)
 */
- (void)showArrowForObject:(id)object;

@end

