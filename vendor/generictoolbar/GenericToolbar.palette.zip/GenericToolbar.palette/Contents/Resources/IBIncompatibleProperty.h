/******************************************************************************
 Copyright (c) 2005-2006 Jordy Rose
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
 
 Except as contained in this notice, the name(s) of the above copyright holders
 shall not be used in advertising or otherwise to promote the sale, use or other
 dealings in this Software without prior authorization.
*******************************************************************************/

@class NSString, NSArray;

#pragma mark PRIVATE class from InterfaceBuilder.framework

#define _IBIncompatiblePropertyType		_InterfaceBuilder_Framework_IncompatiblePropertyType
#define IBIncompatiblePropertyType		InterfaceBuilder_Framework_IncompatiblePropertyType
#define IBNoncriticalIncompatibility	InterfaceBuilder_Framework_NoncriticalIncompatibility
#define IBCriticalIncompatibility		InterfaceBuilder_Framework_CriticalIncompatibility

/*!
 * @enum IBIncompatiblePropertyType
 * Specifies the type of an incompatible property. The actual values are unknown...this
 * is merely reverse engineering.
 * @constant IBNoncriticalIncompatibility The incompatibility is not critical.
 * @constant IBCriticalIncompatibility The incompatibility is critical. This should usually
 * only be used for problems encoding data (classes that don't support unkeyed archiving,
 * for example).
 */
typedef enum _IBIncompatiblePropertyType {
	IBNoncriticalIncompatibility	= 1,
	IBCriticalIncompatibility		= 2
} IBIncompatiblePropertyType;

#define _IBMacOSVersion		_InterfaceBuilder_Framework_IBMacOSVersion
#define IBMacOSVersion		InterfaceBuilder_Framework_IBMacOSVersion
#define IBMacOSVersion10_0	InterfaceBuilder_Framework_MacOSVersion10_0
#define IBMacOSVersion10_1	InterfaceBuilder_Framework_MacOSVersion10_1
#define IBMacOSVersion10_2	InterfaceBuilder_Framework_MacOSVersion10_2
#define IBMacOSVersion10_3	InterfaceBuilder_Framework_MacOSVersion10_3
#define IBMacOSVersion10_4	InterfaceBuilder_Framework_MacOSVersion10_4
/*!
 * @enum IBMacOSVersion
 * Specifies the version of Mac OS X that is incompatible with a property. The value is
 * simply the second part of the version number, but these constants can be used as well.
 * What will happen after Mac OS X v10.9?
 * @constant IBMacOSVersion10_0 Mac OS X v10.0 (Cheetah)
 * @constant IBMacOSVersion10_1 Mac OS X v10.1 (Puma)
 * @constant IBMacOSVersion10_2 Mac OS X v10.2 (Jaguar)
 * @constant IBMacOSVersion10_3 Mac OS X v10.3 (Panther)
 * @constant IBMacOSVersion10_4 Mac OS X v10.4 (Tiger)
 */
typedef enum _IBMacOSVersion {
	IBMacOSVersion10_0	= 0,
	IBMacOSVersion10_1,
	IBMacOSVersion10_2,
	IBMacOSVersion10_3,
	IBMacOSVersion10_4
} IBMacOSVersion;

/*!
 * This class is used with the <code>ibIncompatibleProperties</code> method in
 * <code>IBObjectProtocol</code>. For the most part, you will just need to create
 * these and return them within an array, but only if you have features that are
 * incompatible with earlier versions of the system. WARNING: this class is a PRIVATE
 * part of InterfaceBuilder.framework, so any documentation and usage is not
 * guaranteed to be correct or safe.
 */
@interface IBIncompatibleProperty : NSObject
{
    NSString *_objectName;
    NSString *_message;
    id _object;
    int _version;
    int _type;
}
/*!
 * @functiongroup Creating an IBIncompatibleProperty
 */
/*!
 * Returns a noncritical property with the specified message, and an unknown version.
 * (UNTESTED)
 * @see #propertyWithMessage:version:type:
 */
+ (IBIncompatibleProperty *)propertyWithMessage:(NSString *)message;
/*!
 * Returns a property with the specified message and version. <code>version</code> can
 * be one of the {@link IBMacOSVersion} constants. <code>incompatibilityType</code> can
 * be one of the {@link IBIncompatiblePropertyType} constants, and describes whether an
 * incompatibility is critical or not.
 * (MINOR TESTING ONLY)
 * @see #initWithMessage:version:type:
 * @see #propertyWithMessage:
 */
+ (IBIncompatibleProperty *)propertyWithMessage:(NSString *)message version:(int)version type:(int)incompatibilityType;
/*!
 * Initializes a property with the specified message and version. <code>version</code> can
 * be one of the {@link IBMacOSVersion} constants. <code>incompatibilityType</code> can
 * be one of the {@link IBIncompatiblePropertyType} constants, and describes whether an
 * incompatibility is critical or not.
 * (UNTESTED)
 * @see #propertyWithMessage:version:type:
 */
- (id)initWithMessage:(NSString *)message version:(int)version type:(int)incompatibilityType;

/*!
 * @functiongroup Document information
 */
/*!
 * Sets a nib file's oldest target. <code>version</code> is one of the {@link IBMacOSVersion} constants.
 * (UNTESTED)
 * @see #oldestVersionForDocument:
 */
+ (void)setOldestVersion:(int)version forDocument:(id)document;
/*!
 * Returns a nib file's oldest target, one of the {@link IBMacOSVersion} constants.
 * (UNTESTED)
 * @see #setOldestVersion:forDocument:
 */
+ (int)oldestVersionForDocument:(id)document;
/*!
 * Returns the incompatible properties in the nib file <code>document</code> for the given
 * version of Mac OS. The number of critical incompatibilities is stored in <code>criticalCount</code>.
 * (UNTESTED)
 * @see #incompatiblePropertiesForDocument:version:criticalCount:longestMessageIndex:
 * @see #incompatiblePropertiesForDocument:version:documentSaveType:criticalCount:longestMessageIndex:
 */
+ (NSArray *)incompatiblePropertiesForDocument:(id)document version:(int)version criticalCount:(unsigned int *)criticalCount;
/*!
 * Returns the incompatible properties in the nib file <code>document</code> for the given
 * version of Mac OS. The number of critical incompatibilities is stored in <code>criticalCount</code>,
 * and the index of the longest message is stored in <code>longestMessageIndex</code>. This allows
 * the caller to display the messages at a size proper for the longest one.
 * (UNTESTED)
 * @see #incompatiblePropertiesForDocument:version:criticalCount:
 * @see #incompatiblePropertiesForDocument:version:documentSaveType:criticalCount:longestMessageIndex:
 */
+ (NSArray *)incompatiblePropertiesForDocument:(id)document version:(int)version
								 criticalCount:(unsigned int *)criticalCount longestMessageIndex:(unsigned int *)longestMessageIndex;
/*!
 * Returns the incompatible properties in the nib file <code>document</code> for the given
 * version of Mac OS and file format (keyed or unkeyed). The number of critical incompatibilities
 * is stored in <code>criticalCount</code>, and the index of the longest message is stored in
 * <code>longestMessageIndex</code>. This allows the caller to display the messages at a size
 * proper for the longest one.
 * (UNTESTED)
 * @see #incompatiblePropertiesForDocument:version:criticalCount:
 * @see #incompatiblePropertiesForDocument:version:criticalCount:longestMessageIndex:
 */
+ (NSArray *)incompatiblePropertiesForDocument:(id)document version:(int)version documentSaveType:(int)saveMode
								 criticalCount:(unsigned int *)criticalCount longestMessageIndex:(unsigned int *)longestMessageIndex;

/*!
 * @functiongroup Getting property object information
 */
/*!
 * Sets the name of the object with the incompatibility in question. Typically not needed by
 * palette programmers; IB will take care of it for you.
 * (UNTESTED)
 *
 * @see #objectName
 * @see #setObject:
 * @see #object
 */
- (void)setObjectName:(NSString *)newName;
/*!
 * Returns the name of the object that has this incompatibility.
 * (UNTESTED)
 *
 * @see #setObjectName:
 * @see #setObject:
 * @see #object
 */
- (NSString *)objectName;
/*!
 * Sets the object that has this incompatibility. Typically not needed by
 * palette programmers; IB will take care of it for you.
 * (UNTESTED)
 *
 * @see #setObjectName:
 * @see #objectName
 * @see #object
 */
- (void)setObject:(id)newObject;
/*!
 * Returns the object that has this incompatibility.
 * (UNTESTED)
 *
 * @see #setObjectName:
 * @see #objectName
 * @see #setObject:
 */
- (id)object;

/*!
 * @functiongroup Getting information about the property
 */
/*!
 * Returns the latest version of Mac OS X that is incompatible. The return value will be one
 * of the {@link IBMacOSVersion} constants.
 */
- (int)version;
/*!
 * Returns whether or not the incompatibility is critical. The return value will be one
 * of the {@link IBIncompatiblePropertyType} constants.
 */
- (int)type;
/*!
 * Returns the message displayed to the user in the "Compatibility Checking" panel.
 */
- (NSString *)message;
/*!
 * Returns <code>YES</code> if the object or property is incompatible with Mac OS X v10.0
 * (Cheetah), <code>NO</code> if not.
 * (UNTESTED)
 */
- (BOOL)isCheetahIncompatibility;
/*!
 * Returns <code>YES</code> if the object or property is incompatible with Mac OS X v10.1
 * (Puma), <code>NO</code> if not.
 * (UNTESTED)
 */
- (BOOL)isPumaIncompatibility;
/*!
 * Returns <code>YES</code> if the object or property is incompatible with Mac OS X v10.2
 * (Jaguar), <code>NO</code> if not.
 * (UNTESTED)
 */
- (BOOL)isJaguarIncompatibility;
/*!
 * Returns <code>YES</code> if the object or property is incompatible with Mac OS X v10.3
 * (Panther), <code>NO</code> if not.
 * (UNTESTED)
 */
- (BOOL)isPantherIncompatibility;
/*!
 * Returns <code>YES</code> if the object or property is incompatible with Mac OS X v10.4
 * (Tiger), <code>NO</code> if not.
 * (UNTESTED)
 */
- (BOOL)isTigerIncompatibility;
/*!
 * Returns <code>YES</code> if the object or property is incompatible with the features of
 * the nib file, <code>NO</code> if not.
 * (UNTESTED AND UNKNOWN)
 */
- (BOOL)isFeatureIncompatibility;
/*!
 * Returns <code>YES</code> if the object or property is incompatible with the nib file
 * save format (keyed or unkeyed), <code>NO</code> if not.
 * (UNTESTED)
 */
- (BOOL)isDataIncompatibility;

/*!
 * @functiongroup Unknown methods
 */
/*!
 * Returns the framework bundle containing default error messages for incompatibilities
 * (InterfaceBuilder.framework). See the resource file <code>IBIncompatibleProperties.strings</code>.
 * (UNTESTED AND UNKNOWN)
 */
+ (id)propertyStringsBundle;
/*!
 * Returns the titles of each version of Mac OS X, located within the bundle returned by
 * {@link #propertyStringsBundle} (InterfaceBuilder.framework). See the resource file
 * <code>IBIncompatibleProperties.strings</code>.
 * (UNTESTED AND UNKNOWN)
 */
+ (id)versionTitles;
@end
