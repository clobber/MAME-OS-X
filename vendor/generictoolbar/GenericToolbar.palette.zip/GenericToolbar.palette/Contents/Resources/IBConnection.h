#import <Foundation/Foundation.h>

#pragma mark PRIVATE class from InterfaceBuilder.app

extern Class CLASS_IBConnectionManager;

@interface IBConnectionManager : NSObject
{
    id _source;
    NSWindow *_sourceWindow;
    id _destination;
    NSWindow *_destinationWindow;
    BOOL _isConnecting;
    NSMutableArray *ignoredTrackerWindows;
    BOOL _resuffleWindows;
}

+ (id)sharedConnectionManager;
+ (id)_windowAtScreenPoint:(NSPoint)fp8;
- (id)source;
- (id)sourceWindow;
- (id)destination;
- (id)destinationWindow;
- (BOOL)isConnecting;
- (void)stopConnecting;
- (void)disableStopConnecting;
- (void)enableStopConnecting;
- (id)_actualWindowAtScreenPoint:(NSPoint)fp8;
- (void)trackConnectionFromObject:(id)fp8 inWindow:(id)fp12 event:(id)fp16;
- (void)displayConnectionBetweenSource:(id)fp8 andDestination:(id)fp12;
- (id)_connectDestinationAtPoint:(NSPoint)fp8 rect:(NSRectPointer)fp16 window:(id)fp20;
- (id)connectDestinationAtPoint:(NSPoint)fp8 rect:(NSRectPointer)fp16;
- (void)showConnectFrame:(NSRectPointer)fp8 target:(id)fp24;
- (void)hideConnectFrame;
- (void)showArrowForObject:(id)fp8;

@end

